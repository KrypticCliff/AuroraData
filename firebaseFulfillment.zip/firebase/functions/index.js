'use strict';
 
const functions = require('firebase-functions');
const dialogflow = require('actions-on-google');
const {WebhookClient} = require('dialogflow-fulfillment');
const {Payload} = require('dialogflow-fulfillment');

const admin = require('firebase-admin'); // initialise DB connection, letting fulfillment compiler know what method you intend to use for the connection

admin.initializeApp(functions.config().firebase);
var db = admin.firestore();

process.env.DEBUG = 'dialogflow:debug'; // enables lib debugging statements (so you can read actual error/success logs should they occur)

const timeZone = 'America/Los_Angeles'; //set the timezone so timestamps are correct UTC
const timeZoneOffset = '-07:00'; 

exports.dialogflowFirebaseFulfillment = functions.https.onRequest((request, response) => { //newish way for Node.JS functions to pass fulfillment  
  const agent = new WebhookClient({ request, response });
  
  console.log('Dialogflow Request headers: ' + JSON.stringify(request.headers));
  console.log('Dialogflow Request body: ' + JSON.stringify(request.body));
  
  function fsQuery(db) {
    const [course_prefix, course_number, term, year] = [agent.parameters.course_prefix, agent.parameters.course_number, agent.parameters.term, agent.parameters.year]; 
    const missingSlots = [];

    if (!course_prefix) { missingSlots.push('course_prefix'); } 
    if (!course_number) { missingSlots.push('course_number'); }
    if (!term) { missingSlots.push('term'); }
	if (!year) { missingSlots.push('year'); }

     if (missingSlots.length === 1){
        agent.add(`Looks like you didn't provide a ${missingSlots[0]}`);
     }
      else if (missingSlots.length === 2){
        agent.add(`Ok, I need two more things, a ${missingSlots[0]} and ${missingSlots[1]}`);
     }
     else if (missingSlots.length === 3){
        agent.add(`Ok, I need 3 things still: a ${missingSlots[0]}, ${missingSlots[1]}, and ${missingSlots[2]}`);
	 }
     else if (missingSlots.length === 4){ //gathering variable responses from the user starts here:
        agent.add(`Ok, Great! lets get started, I just need 4 things: a ${missingSlots[0]}, ${missingSlots[1]}, ${missingSlots[2]}, and ${missingSlots[3]}`);
     } 
       
    var query = db.collection('CSUSB').where('COURSE_NUMBER', '==', course_number)
        .get().then(snapshot => {
          snapshot.docs.forEach(doc => {
          	agent.add(term + year);
          });
      	})
      	.catch(err => {
        	console.log('Error getting documents', err);
      	});
    return query;
  }
  
  /* TEST CODE
  function handleAge(agent) {
    const age = agent.parameters.age;

    agent.add(`Thank you...`);

    return admin.database().ref('ageInfo').transaction((ageInfo) => {
      if(ageInfo !== null) {
        let oldAverage = ageInfo.runningAverage;
        let oldTotalCount = ageInfo.totalCount;
        let newAverage = (oldAverage * oldTotalCount + age) / (oldTotalCount + 1);
        ageInfo.runningAverage = newAverage;
        ageInfo.totalCount+=1;
        agent.add(`Our recorded average age is ` + newAverage);
      }
      return ageInfo;
    }, function(error, isSuccess) {
      console.log('Update average age transaction success: ' + isSuccess);
    });
*/

  // Run the proper function handler based on the matched Dialogflow intent name
  let intentMap = new Map();
  //intentMap.set('AskAge', handleAge);
  intentMap.set('StudentsEnrolled', fsQuery); 
  agent.handleRequest(intentMap);
});